
import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import RecaptchaPlugin from 'puppeteer-extra-plugin-recaptcha';
import fs from 'fs';
import express from 'express';

// Khởi tạo Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());

// Biến lưu trữ các URL đã được gửi
let sentUrls = [];

// Hàm kiểm tra URL đã tồn tại chưa
function isUrlExists(url) {
    return sentUrls.some(item => item.url === url);
}

// Hàm xóa URLs cũ hơn 1 phút
function cleanupOldUrls() {
    const oneMinuteAgo = new Date(Date.now() - 60000); // 1 phút trước
    const initialCount = sentUrls.length;
    sentUrls = sentUrls.filter(item => new Date(item.timestamp) > oneMinuteAgo);
    
    if (sentUrls.length < initialCount) {
        console.log(`Đã xóa ${initialCount - sentUrls.length} URLs cũ hơn 1 phút`);
    }
}

// Chạy cleanup mỗi 30 giây
setInterval(cleanupOldUrls, 30000);

// Route chính - hiển thị danh sách URLs dạng JSON đơn giản cho tool khác
app.get('/', (req, res) => {
  res.json({
    status: 'active',
    total_urls: sentUrls.length,
    last_updated: new Date().toISOString(),
    urls: sentUrls.map(item => ({
      url: item.url,
      timestamp: item.timestamp,
      request_number: item.requestNumber
    }))
  });
});

// Route để tự động chuyển tiếp đến URL mới nhất
app.get('/redirect-latest', (req, res) => {
  if (sentUrls.length === 0) {
    return res.status(404).json({
      error: 'Không có URL nào để chuyển tiếp',
      message: 'Hãy chạy automation để thu thập URLs trước'
    });
  }
  
  // Lấy URL mới nhất (phần tử cuối cùng trong mảng)
  const latestUrl = sentUrls[sentUrls.length - 1];
  
  console.log(`Chuyển tiếp đến URL mới nhất: ${latestUrl.url}`);
  
  // Chuyển tiếp đến URL
  res.redirect(latestUrl.url);
});

// Route để lấy URL mới nhất dạng JSON
app.get('/latest-url', (req, res) => {
  if (sentUrls.length === 0) {
    return res.status(404).json({
      error: 'Không có URL nào',
      message: 'Hãy chạy automation để thu thập URLs trước'
    });
  }
  
  const latestUrl = sentUrls[sentUrls.length - 1];
  
  res.json({
    url: latestUrl.url,
    timestamp: latestUrl.timestamp,
    request_number: latestUrl.requestNumber,
    time_remaining: Math.max(0, 60 - Math.floor((Date.now() - new Date(latestUrl.timestamp).getTime()) / 1000))
  });
});
app.use((req, res) => {
    const targetUrl = sentUrls.length > 0 
      ? sentUrls[sentUrls.length - 1].url  // socialUrl mới nhất
      : 'https://www.ebay.com';            // trang chủ nếu chưa có socialUrl
  
    console.log(`Redirecting to: ${targetUrl}`);
    res.redirect(targetUrl);  // 302 redirect
  });
// Route để hiển thị giao diện quản lý URLs
app.get('/urls-ui', (req, res) => {
  res.sendFile(__dirname + '/urls.html');
});

// Route để hiển thị các URL đã được gửi
app.get('/urls', (req, res) => {
  res.json({
    totalUrls: sentUrls.length,
    urls: sentUrls
  });
});

// Route để xóa tất cả URLs
app.delete('/urls', (req, res) => {
  const deletedCount = sentUrls.length;
  sentUrls = [];
  res.json({
    message: `Đã xóa ${deletedCount} URLs`,
    totalUrls: 0
  });
});

// Route để xóa URL cụ thể theo index
app.delete('/urls/:index', (req, res) => {
  const index = parseInt(req.params.index);
  if (index >= 0 && index < sentUrls.length) {
    const deletedUrl = sentUrls.splice(index, 1)[0];
    res.json({
      message: 'Đã xóa URL thành công',
      deletedUrl: deletedUrl,
      totalUrls: sentUrls.length
    });
  } else {
    res.status(404).json({ error: 'Không tìm thấy URL với index này' });
  }
});

// Route để kích hoạt automation
app.post('/start', async (req, res) => {
  try {
    await runAutomation();
    res.json({ status: 'success', message: 'Automation started successfully' });
  } catch (error) {
    console.error('Error in automation:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

// Khởi động server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// Hàm kiểm tra xem có CAPTCHA không
async function checkForCaptcha(page) {
    try {
        // Các selector phổ biến của CAPTCHA
        const captchaSelectors = [
            'iframe[src*="recaptcha"]',
            'iframe[src*="hcaptcha"]',
            'div.recaptcha',
            'div.g-recaptcha',
            'div.h-captcha',
            'div#captcha',
            'div.captcha',
            'img[alt="CAPTCHA"]',
            'img[alt="captcha"]',
            'div[class*="captcha"]',
            'div[class*="Captcha"]',
            'div[class*="CAPTCHA"]'
        ];

        for (const selector of captchaSelectors) {
            const captchaElement = await page.$(selector);
            if (captchaElement) {
                const isVisible = await captchaElement.isIntersectingViewport();
                if (isVisible) {
                    console.log('Phát hiện CAPTCHA với selector:', selector);
                    return true;
                }
            }
        }
        
        // Kiểm tra các selector CAPTCHA trực tiếp
        const captchaElementSelectors = [
            'iframe[src*="recaptcha"]',
            'iframe[src*="hcaptcha"]',
            'div.g-recaptcha',
            'div.h-captcha',
            '#captcha',
            'div.captcha',
            'img[alt="CAPTCHA"]',
            'img[alt="captcha"]'
        ];
        
        for (const selector of captchaElementSelectors) {
            const elements = await page.$$(selector);
            for (const element of elements) {
                try {
                    const isVisible = await element.isIntersectingViewport();
                    if (isVisible) {
                        console.log(`Phát hiện CAPTCHA với selector: ${selector}`);
                        return true;
                    }
                } catch (error) {
                    // Bỏ qua nếu không thể kiểm tra visibility
                }
            }
        }
        
        // Chỉ kiểm tra từ khóa khi không tìm thấy element CAPTCHA
        const content = await page.content();
        const captchaKeywords = [
            'I\'m not a robot',
            'I am not a robot',
            'recaptcha',
            'hcaptcha'
        ];
        
        // Chỉ trả về true nếu tìm thấy ít nhất 2 từ khóa để tránh dương tính giả
        const foundKeywords = captchaKeywords.filter(keyword => content.includes(keyword));
        if (foundKeywords.length >= 2) {
            console.log(`Phát hiện từ khóa CAPTCHA: ${foundKeywords.join(', ')}`);
            return true;
        }
        
        return false;
    } catch (error) {
        console.log('Lỗi khi kiểm tra CAPTCHA:', error.message);
        return false;
    }
}

// Hàm xử lý khi phát hiện CAPTCHA
async function handleCaptcha(page) {
    console.log('Đang xử lý CAPTCHA...');
    
    try {
        // Chụp ảnh màn hình khi phát hiện CAPTCHA
        await page.screenshot({ path: 'captcha_detected.png' });
        console.log('Đã lưu ảnh CAPTCHA vào captcha_detected.png');
        
        // Thử giải quyết CAPTCHA tự động nếu có thể
        try {
            await page.solveRecaptchas();
            console.log('Đã thử giải quyết CAPTCHA tự động');
            
            // Chờ 5 giây để xem CAPTCHA có được giải quyết không
            await new Promise(resolve => setTimeout(resolve, 5000));
            
            // Kiểm tra lại xem CAPTCHA còn không
            const stillHasCaptcha = await checkForCaptcha(page);
            if (!stillHasCaptcha) {
                console.log('CAPTCHA đã được giải quyết thành công!');
                return true;
            }
        } catch (error) {
            console.log('Không thể giải quyết CAPTCHA tự động:', error.message);
        }
        
        // Nếu không thể giải quyết tự động, yêu cầu người dùng nhập thủ công
        console.log('Vui lòng giải quyết CAPTCHA thủ công trong 2 phút...');
        
        // Đợi tối đa 2 phút để người dùng giải quyết CAPTCHA
        const maxWaitTime = 2 * 60 * 1000; // 2 phút
        const startTime = Date.now();
        
        while (Date.now() - startTime < maxWaitTime) {
            await new Promise(resolve => setTimeout(resolve, 5000)); // Kiểm tra mỗi 5 giây
            
            const stillHasCaptcha = await checkForCaptcha(page);
            if (!stillHasCaptcha) {
                console.log('Người dùng đã giải quyết xong CAPTCHA!');
                return true;
            }
            
            console.log('Vẫn đang chờ giải quyết CAPTCHA...');
        }
        
        console.log('Hết thời gian chờ giải quyết CAPTCHA');
        return false;
    } catch (error) {
        console.log('Lỗi khi xử lý CAPTCHA:', error.message);
        return false;
    }
}

// Hàm di chuyển chuột ngẫu nhiên
async function moveMouseRandomly(page) {
    try {
        const viewport = await page.viewport();
        const width = viewport.width;
        const height = viewport.height;
        
        // Tạo 3-5 điểm di chuyển ngẫu nhiên
        const steps = Math.floor(Math.random() * 3) + 3;
        let lastX = Math.floor(Math.random() * width);
        let lastY = Math.floor(Math.random() * height);
        
        for (let i = 0; i < steps; i++) {
            const x = Math.floor(Math.random() * width);
            const y = Math.floor(Math.random() * height);
            
            // Di chuyển chuột đến vị trí mới với các bước mượt mà
            await page.mouse.move(x, y, { 
                steps: 10 + Math.floor(Math.random() * 10) // Số bước ngẫu nhiên từ 10-20
            });
            
            // Thời gian chờ ngẫu nhiên giữa các lần di chuyển
            const delay = 100 + Math.random() * 400; // 100-500ms
            await new Promise(resolve => setTimeout(resolve, delay));
            
            // Kiểm tra CAPTCHA sau khi di chuyển chuột
            await checkAndHandleCaptcha(page);
        }
        
        return { x: lastX, y: lastY };
    } catch (error) {
        console.log('Lỗi khi di chuyển chuột:', error.message);
        return null;
    }
}

// Add stealth plugin and use defaults (all tricks to hide puppeteer)
puppeteer.use(StealthPlugin());

// Add recaptcha plugin and provide it your 2captcha token
// 2captcha is the recommended provider with the best success rate
puppeteer.use(
  RecaptchaPlugin({
    provider: {
      id: '2captcha',
      token: '077798c64a2e77a12f1c95c5d436f380' // Using the provided 2CAPTCHA API KEY
    }
  })
);


// Hàm kiểm tra và xử lý CAPTCHA nếu có
async function checkAndHandleCaptcha(page) {
    const hasCaptcha = await checkForCaptcha(page);
    if (hasCaptcha) {
        console.log('Phát hiện CAPTCHA, đang xử lý...');
        const captchaSolved = await handleCaptcha(page);
        if (!captchaSolved) {
            throw new Error('Không thể giải quyết CAPTCHA');
        }
    }
}

// Hàm chạy tự động
async function runAutomation() {
    console.log('Starting automation...');
    console.log('Puppeteer executable path:', process.env.NODE_ENV == 'production' ? process.env.PUPPETEER_EXECUTABLE_PATH : puppeteer.executablePath());
    
    let browser;
    try {
    // Launch the browser with proxy configuration
    const browser = await puppeteer.launch({
        headless: false,
        //headless:'new',
        userDataDir: './hm-profile',
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--single-process',
          '--disable-gpu',
          '--disable-software-rasterizer',
          '--disable-features=IsolateOrigins,site-per-process',
          '--proxy-server=http://us-free-proxy.g-w.info:59781'
        ]
      });
    
      const page = await browser.newPage();
    
      // Proxy authentication
      await page.authenticate({
        username: 'user3proxyserver',
        password: 'huccuAn_oc7o87hubhjYY'

      });
    
      await page.goto('https://api.ipify.org?format=json', { waitUntil: 'networkidle2' });
    
    // Thiết lập timeout cho page
    const timeout = 15000; // Page-level timeout
    page.setDefaultTimeout(timeout);

    console.log('Setting viewport...');
    await page.setViewport({
        width: 736,
        height: 694
    });

    console.log('Navigating to eBay sign-in page...');
    try {
        const response = await page.goto('https://www.ebay.com/signin/?sgn=reg&siteid=0', {
            waitUntil: 'networkidle2',
            timeout: 60000
        });
        console.log(`Page loaded with status: ${response.status()}`);
    } catch (error) {
        console.error('Error navigating to eBay:', error);
        throw error;
    }

    console.log('Looking for and solving reCAPTCHAs...');
    try {
        const { captchas, solutions, solved, error } = await page.solveRecaptchas();
        console.log(`Solved ${solved.length} captchas.`);
    } catch (err) {
        console.error("Error solving captchas:", err);
    }
    
    // The rest of your script...
    // Note: The locators below are very specific and might break if eBay changes its layout.
    // Consider using more robust selectors if you encounter issues.

    try {
        console.log('Continuing with Apple sign-in...');
        
        // Hàm xuất cookie ra file
        const saveCookiesToFile = async (filename) => {
            try {
                const cookies = await page.cookies();
                const filePath = `${filename}`;
                
                fs.writeFileSync(filePath, JSON.stringify(cookies, null, 2));
                console.log(`Cookies saved to: ${filePath}`);
                console.log(`Total cookies saved: ${cookies.length}`);
                
                // Log thông tin cookie quan trọng
                const importantCookies = cookies.filter(cookie => 
                    cookie.name.includes('session') || 
                    cookie.name.includes('token') || 
                    cookie.name.includes('auth') ||
                    cookie.name.includes('ebay') ||
                    cookie.domain.includes('ebay')
                );
                
                if (importantCookies.length > 0) {
                    console.log('Important cookies found:');
                    importantCookies.forEach(cookie => {
                        console.log(`  - ${cookie.name}: ${cookie.value.substring(0, 20)}... (domain: ${cookie.domain})`);
                    });
                }
                
                return true;
            } catch (error) {
                console.error('Error saving cookies:', error);
                return false;
            }
        };

        console.log('Waiting 5 seconds for page to load after first click...');
        await moveMouseRandomly(page);
        await new Promise(resolve => setTimeout(resolve, 5000));
        await moveMouseRandomly(page);
        const appleButtonSelectors = [
            'div.psi__container-r3 span > span',
            'xpath///*[@id="signin_appl_btn"]/span/span',
            'pierce/div.psi__container-r3 span > span',
            'text/Continue with Apple'
        ];
        
        // Tìm và click vào nút đăng nhập Apple
        let appleButtonFound = false;
        for (const selector of appleButtonSelectors) {
            try {
                await page.waitForSelector(selector, { timeout: 5000 });
                await page.click(selector);
                appleButtonFound = true;
                console.log('Clicked Apple sign-in button with selector:', selector);
                break;
            } catch (error) {
                console.log(`Selector not found: ${selector}`);
            }
        }
        
        if (!appleButtonFound) {
            throw new Error('Could not find Apple sign-in button with any selector');
        }

        console.log('Entering password...');
        await new Promise(resolve => setTimeout(resolve, 5000));
        await moveMouseRandomly(page);
        await new Promise(resolve => setTimeout(resolve, 2000));
        await moveMouseRandomly(page);
        // Định nghĩa các selector có thể có cho trường mật khẩu
        const passwordSelectors = [
            '#password_text_field',
            'input[type="password"]',
            '::-p-aria(Password)'
        ];
        
        // Tìm và điền mật khẩu
        let passwordFieldFound = false;
        for (const selector of passwordSelectors) {
            try {
                await page.waitForSelector(selector, { timeout: 5000 });
                await page.type(selector, 'Nancyhd1');
                passwordFieldFound = true;
                console.log('Filled password field with selector:', selector);
                break;
            } catch (error) {
                console.log(`Password field not found with selector: ${selector}`);
            }
        }
        
        if (!passwordFieldFound) {
            throw new Error('Could not find password field with any selector');
        }

        console.log('Clicking Sign In...');
        // Định nghĩa các selector có thể có cho nút đăng nhập
        const signInButtonSelectors = [
            '#sign-in',
            'button#sign-in',
            '#sign-in > span',
            'button.signin-v2__buttons-wrapper__button-wrapper__button',
            '.signin-v2__buttons-wrapper__button-wrapper__button',
            'xpath///*[@id="sign-in"]',
            'xpath///*[@id="sign-in"]/span',
            'xpath//button[@class="signin-v2__buttons-wrapper__button-wrapper__button"]',
            'xpath//span[contains(@class, "signin-v2__buttons-wrapper__button-wrapper__button__text") and text()="Sign In"]'
        ];
        
        // Tìm và click vào nút đăng nhập
        let signInButtonFound = false;
        for (const selector of signInButtonSelectors) {
            try {
                await page.waitForSelector(selector, { timeout: 4000 });
                await page.click(selector);
                signInButtonFound = true;
                console.log('Clicked sign-in button with selector:', selector);
                console.log('Successfully clicked sign-in button, waiting for navigation...');
                await new Promise(resolve => setTimeout(resolve, 3000));
                await moveMouseRandomly(page);
                
                // Thử click lại nút đăng nhập nếu vẫn hiển thị (vì nút có thể xuất hiện 2 lần)
                console.log('Checking if sign-in button is still visible for second click...');
                try {
                    // Kiểm tra xem nút có vẫn hiển thị không
                    const isStillVisible = await page.evaluate((sel) => {
                        const element = document.querySelector(sel);
                        return element && element.offsetParent !== null;
                    }, selector);
                    
                    if (isStillVisible) {
                        console.log('Sign-in button is still visible, clicking again...');
                        await page.click(selector);
                        console.log('Clicked sign-in button second time');
                        await new Promise(resolve => setTimeout(resolve, 2000));
                        await moveMouseRandomly(page);
                        
                        // Xuất cookie sau khi click nút đăng nhập lần thứ hai
                        await saveCookiesToFile('cookies_after_signin.json');
                    } else {
                        console.log('Sign-in button is no longer visible');
                        
                        // Xuất cookie sau khi click nút đăng nhập lần đầu
                        await saveCookiesToFile('cookies_after_first_signin_click.json');
                    }
                } catch (error) {
                    console.log('Error checking button visibility:', error.message);
                }
                
                // Thêm delay sau khi click lần thứ hai
                console.log('Waiting after second click...');
                await moveMouseRandomly(page);
                await new Promise(resolve => setTimeout(resolve, 1000));
                await moveMouseRandomly(page);
                
                // Chờ và xử lý các bước tiếp theo sau khi đăng nhập thành công
                console.log('Waiting for next steps after sign-in...');
                await new Promise(resolve => setTimeout(resolve, 5000));
                await moveMouseRandomly(page);
                
                // Tìm và click vào nút Continue sau khi đăng nhập
                const firstContinueButtonSelectors = [
                    'aria/Continue',
                    'aria/[role="generic"]',
                    'button.button-primary > div',
                    'xpath///*[@id="1758345294146-0"]/div/div/button[1]/div',
                    'pierce/button.button-primary > div',
                    'text/Continue'
                ];
                
                let firstContinueButtonFound = false;
                for (const selector of firstContinueButtonSelectors) {
                    try {
                        await page.waitForSelector(selector, { timeout: 5000 });
                        await page.click(selector);
                        firstContinueButtonFound = true;
                        console.log('Clicked Continue button with selector:', selector);
                        
                        // Xuất cookie sau khi click Continue lần đầu
                        await saveCookiesToFile('cookies_after_first_continue.json');
                        
                        break;
                    } catch (error) {
                        console.log(`Continue button not found with selector: ${selector}`);
                    }
                }
                
                if (!firstContinueButtonFound) {
                    console.log('Continue button not found, proceeding to next steps...');
                }
                
                // Chờ trang tải và nhập email nếu cần
                await new Promise(resolve => setTimeout(resolve, 3000));
                await moveMouseRandomly(page);
                
                // Tìm trường email và nhập giá trị
                const emailSelectors = [
                    'input[type="email"]',
                    'input[name="email"]',
                    'input[id*="email"]',
                    'input[placeholder*="email"]',
                    'input[placeholder*="Email"]',
                    '#email',
                    'aria/Email (optional)',
                    'xpath///*[@id="email"]',
                    'xpath//input[@type="email"]',
                    'xpath//input[contains(@name, "email")]',
                    'pierce/#email'
                ];
                
                let emailFieldFound = false;
                for (const selector of emailSelectors) {
                    try {
                        await page.waitForSelector(selector, { timeout: 5000 });
                        const randomString = Math.random().toString(36).substring(2, 10);
                        const randomEmail = `${randomString}@icloud.com`;
                        await page.type(selector, randomEmail);
                        emailFieldFound = true;
                        console.log('Filled email field with selector:', selector);
                        break;
                    } catch (error) {
                        console.log(`Email field not found with selector: ${selector}`);
                    }
                }
                
                if (!emailFieldFound) {
                    console.log('Email field not found, checking if we need to proceed to next steps...');
                    // Có thể trang không yêu cầu email hoặc đã chuyển sang bước khác
                    // Thử tìm các nút tiếp theo hoặc kiểm tra URL hiện tại
                    const currentUrl = page.url();
                    console.log('Current URL:', currentUrl);
                    
                    // Nếu đã ở trang cuối cùng, có thể không cần nhập email
                    if (currentUrl.includes('signup.ebay.com') || currentUrl.includes('socialreg')) {
                        console.log('Already on final registration page, proceeding...');
                    }
                }
                
                if (emailFieldFound) {
                    // Click vào nút Continue cuối cùng
                    const finalContinueSelectors = [
                        'aria/Continue',
                        '#link_success_btn',
                        'xpath///*[@id="link_success_btn"]',
                        'pierce/#link_success_btn',
                        'text/Continue'
                    ];
                    
                    for (const selector of finalContinueSelectors) {
                        try {
                            await page.waitForSelector(selector, { timeout: 5000 });
                            await page.click(selector);
                            console.log('Clicked final Continue button with selector:', selector);
                            break;
                        } catch (error) {
                            console.log(`Final Continue button not found with selector: ${selector}`);
                        }
                    }
                }
                try {
                    // Chờ tối đa 10 giây cho nút Continue xuất hiện
                    await page.waitForSelector('button.button-primary.nav-action .overflow-text:has-text("Continue")', { 
                        timeout: 8000,
                        visible: true 
                    });
                    
                    // Click nút Continue
                    await page.click('button.button-primary.nav-action');
                    console.log('Clicked Continue button with specific selector');
                    continue;
                } catch (error) {
                    console.log('Specific Continue button not found, trying other selectors...');
                }
                
                // Nếu không tìm thấy bằng selector cụ thể, thử các selector khác
                const secondContinueButtonSelectors = [
                    // Selector chính xác dựa trên HTML
                    'button.button-primary.nav-action',
                    'div.primary-button-group > button.button-primary',
                    
                    // Selector phụ trợ
                    'button[class*="button-primary"][class*="nav-action"]',
                    'button:has(> .overflow-text:has-text("Continue"))',
                    'div.overflow-text:has-text("Continue")',
                    'div:has(> div.overflow-text:has-text("Continue"))',
                    'button:has-text("Continue")',
                    'div:has-text("Continue")',
                ];
                
                // Thử click bằng JavaScript nếu không tìm thấy bằng cách thông thường
                const tryClickWithJS = async (selector) => {
                    return await page.evaluate((sel) => {
                        const element = document.querySelector(sel);
                        if (element) {
                            element.click();
                            return true;
                        }
                        return false;
                    }, selector);
                };
                
                let secondContinueButtonFound = false;
                for (const continueSelector of secondContinueButtonSelectors) {
                    try {
                        await page.waitForSelector(continueSelector, { timeout: 5000 });
                        
                        // Thử click bằng JavaScript
                        const clicked = await page.evaluate((selector) => {
                            const element = document.querySelector(selector);
                            if (element) {
                                element.click();
                                console.log('Successfully clicked using JavaScript');
                                return true;
                            }
                            return false;
                        }, continueSelector);
                        
                        // Nếu click JS không thành công, thử click bình thường
                        if (!clicked) {
                            await page.click(continueSelector);
                            console.log('Clicked using normal click');
                        }
                        
                        secondContinueButtonFound = true;
                        console.log('Successfully clicked Continue button with selector:', continueSelector);
                        
                        // Xuất cookie sau khi click Continue lần thứ hai
                        await saveCookiesToFile('cookies_after_second_continue.json');
                        
                        break;
                    } catch (error) {
                        console.log(`Continue button not found with selector: ${continueSelector}`);
                    }
                }
                
                if (!secondContinueButtonFound) {
                    console.log('Could not find any Continue button to click');
                } else {
                    // Chờ 10 giây cho trang load xong
                    console.log('Waiting 10 seconds before filling email...');
                    await moveMouseRandomly(page);
                    await new Promise(resolve => setTimeout(resolve, 3000));
                    await moveMouseRandomly(page);
                    
                    // Tạo email ngẫu nhiên
                    const randomString = Math.random().toString(36).substring(2, 10);
                    const randomEmail = `test${randomString}@gmail.com`;
                    
                    // Điền email vào trường input nếu có
                    try {
                        // Kiểm tra xem có trường email không
                        const emailField = await page.$('input#email');
                        if (emailField) {
                            await page.type('input#email', randomEmail, { delay: 100 });
                            console.log('Filled random email:', randomEmail);
                            
                            // Xuất cookie sau khi nhập email
                            await saveCookiesToFile('cookies_after_email_input.json');
                            
                            // Chờ 1 giây rồi click nút Continue
                            await new Promise(resolve => setTimeout(resolve, 1000));
                            
                            // Thử click nút Continue với các selector ưu tiên
                            const continueSelectors = [
                                'button#link_success_btn',
                                'button[type="submit"]',
                                'button:has-text("Continue")',
                                'button.button-primary',
                                'button.primary',
                                'button.btn--primary',
                                'button.continue'
                            ];
                            
                            for (const selector of continueSelectors) {
                                const button = await page.$(selector);
                                if (button) {
                                    const isVisible = await button.isVisible();
                                    if (isVisible) {
                                        await button.click();
                                        console.log('Đã click nút Continue với selector:', selector);
                                        await new Promise(resolve => setTimeout(resolve, 3000));
                                        break;
                                    }
                                }
                            }
                        } else {
                            console.log('No email field found, skipping email input step');
                        }
                    } catch (error) {
                        console.log('Error during email input or continue click:', error.message);
                    }
                }
                
                try {
                    await new Promise(resolve => setTimeout(resolve, 10000)); // Tăng thời gian chờ lên 10s
                    const socialUrl = page.url();
                    const sleep = ms => new Promise(r => setTimeout(r, ms));
                    
                    if (socialUrl.includes("socialreg")) {
                        const totalRequests = 85;
                        for (let i = 0; i < totalRequests; i++) {
                            try {
                                // Kiểm tra URL đã tồn tại chưa
                                if (!isUrlExists(socialUrl)) {
                                    // Lưu URL vào mảng sentUrls
                                    sentUrls.push({
                                        url: socialUrl,
                                        timestamp: new Date().toISOString(),
                                        requestNumber: i + 1
                                    });
                                    
                                    console.log(`URL đã được lưu: ${socialUrl}`);
                                } else {
                                    console.log(`URL đã tồn tại, bỏ qua: ${socialUrl}`);
                                }
                                
                                await sleep(1000); // delay 1 giây giữa các request
                            } catch (error) {
                                console.error(`Error on request ${i + 1}:`, error.message);
                            }

                        }
                        await sleep(3000); // delay 3 giây sau khi hoàn thành tất cả request
                    }
                } catch (error) {
                    console.error('Lỗi khi lưu URL vào file:', error.message);
                }
                
                // Xuất cookie cuối cùng trước khi đóng browser
                console.log('Saving final cookies before closing browser...');
                await saveCookiesToFile('cookies_final.json');
                
                await browser.close();
                process.exit(0);
                
                break;
            } catch (error) {
                console.log(`Sign-in button not found with selector: ${selector}`);
            }
        }
        
        if (!signInButtonFound) {
            throw new Error('Could not find sign-in button with any selector');
        }
        
        // ... (the rest of your automation script)
        
    } catch (error) {
        console.error('An error occurred during the automation steps after captcha solving:', error);
    }


    } catch (error) {
        console.error('Error in automation:', error);
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

// Hàm chạy lặp lại liên tục
async function runLoop() {
    let runCount = 0;
    while (true) {
        runCount++;
        const startTime = new Date();
        console.log(`\n=== Bắt đầu lần chạy thứ ${runCount} lúc ${startTime.toLocaleString()} ===`);
        
        try {
            await runAutomation();
        } catch (error) {
            console.error('Lỗi trong quá trình chạy tự động:', error);
        }
        
        const endTime = new Date();
        const duration = (endTime - startTime) / 1000; // tính bằng giây
        
        console.log(`\nHoàn thành lần chạy thứ ${runCount} trong ${duration.toFixed(2)} giây`);
        console.log('Chuẩn bị chạy lại...');
    }
}

// Bắt đầu chạy vòng lặp
runLoop().catch(err => {
    console.error('Fatal error in main loop:', err);
    process.exit(1);
});